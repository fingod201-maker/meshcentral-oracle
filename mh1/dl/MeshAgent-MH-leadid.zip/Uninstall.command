#!/bin/bash

echo "Stopping meshagent..."
sudo /bin/launchctl bootout system "/Library/LaunchDaemons/meshagent.plist" &> /dev/null || sudo /bin/launchctl unload "/Library/LaunchDaemons/meshagent.plist" &> /dev/null
sudo pkill -9 "meshagent" &> /dev/null || true
CONSOLE_USER=$(stat -f '%Su' /dev/console 2>/dev/null || true)
CONSOLE_UID=$(id -u "${CONSOLE_USER}" 2>/dev/null || true)
if [ -n "${CONSOLE_UID}" ] && [ "${CONSOLE_UID}" != "0" ]; then
    sudo /bin/launchctl bootout "gui/${CONSOLE_UID}" "/Library/LaunchAgents/meshagent-launchagent.plist" &> /dev/null || true
fi
sudo /bin/launchctl unload "/Library/LaunchDaemons/meshagentDiagnostic_periodicStart.plist" &> /dev/null
sudo /bin/launchctl unload "/Library/LaunchDaemons/meshagentDiagnostic.plist" &> /dev/null
sudo rm "/Library/LaunchDaemons/meshagentDiagnostic_periodicStart.plist" &> /dev/null
sudo rm "/Library/LaunchDaemons/meshagentDiagnostic.plist" &> /dev/null

echo "Resetting TCC permissions for meshagent..."
BUNDLE_ID=$(mdls -name kMDItemCFBundleIdentifier -raw "/usr/local/mesh_services/meshagent/meshagent/meshagent" 2>/dev/null || true)
if [ -n "${BUNDLE_ID}" ] && [ "${BUNDLE_ID}" != "(null)" ]; then
    sudo tccutil reset All "${BUNDLE_ID}" &> /dev/null || true
fi
sudo tccutil reset All "meshagent" &> /dev/null || true

sudo rm "/usr/local/mesh_services/meshagent/meshagent/meshagent" &> /dev/null
sudo rm "/usr/local/mesh_services/meshagent/meshagent/meshagent.msh" &> /dev/null
sudo rm "/usr/local/mesh_services/meshagent/meshagent/meshagent.db" &> /dev/null
sudo rm "/usr/local/mesh_services/meshagentDiagnostic/meshagentDiagnostic" &> /dev/null
sudo rm "/Library/LaunchDaemons/meshagent.plist" &> /dev/null
sudo rm "/Library/LaunchAgents/meshagent-launchagent.plist" &> /dev/null
echo "meshagent was uninstalled."
